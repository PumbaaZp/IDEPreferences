#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
  *@Description TODO
  *@Author ${USER}
  *@Date ${DATE}
**/
public class ${NAME} {
}
